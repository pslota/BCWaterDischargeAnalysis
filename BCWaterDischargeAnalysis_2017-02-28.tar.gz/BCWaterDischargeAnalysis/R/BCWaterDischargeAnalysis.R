#' Performs analysis on water discharge from streams
#'
#' This is a suite of functions to mimic the HEC package analysis of stream discharge data..
#'
"_PACKAGE"
#> [1] "_PACKAGE"
