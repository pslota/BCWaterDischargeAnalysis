#' @param csv.nddigits Number of decimal digits to be rounded to when creating *.csv files.
