#' @param Station.Code A character string. Used to names any *.csv or *.pdf files created so be careful
#'          that the Station.Code will be acceptable in a file name.
