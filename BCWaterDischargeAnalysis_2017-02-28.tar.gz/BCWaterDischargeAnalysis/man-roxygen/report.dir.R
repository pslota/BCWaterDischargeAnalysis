#' @param report.dir Directory in which *.csv or *.pdf files are stored.
