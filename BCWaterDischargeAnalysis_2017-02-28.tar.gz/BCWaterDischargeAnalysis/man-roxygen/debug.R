#' @param debug Internal flag used for debugging
